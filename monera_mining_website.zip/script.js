// Function to handle form submission for the contact form
document.getElementById("contact-form").addEventListener("submit", function(event) {
    event.preventDefault();
    alert("Thank you for your message! We'll get back to you soon.");
    this.reset();
});

// Function to handle plan purchases
const purchaseButtons = document.querySelectorAll(".purchase-btn");

purchaseButtons.forEach(button => {
    button.addEventListener("click", function() {
        const planName = this.parentElement.querySelector("h3").innerText;
        alert(`Congratulations! You've successfully purchased the ${planName}.`);
        updateProfit(planName);
    });
});

// Function to update profit based on the purchased plan
function updateProfit(plan) {
    let profitRate;

    switch (plan) {
        case "Basic Plan":
            profitRate = 10; // Replace with actual profit calculation
            break;
        case "Standard Plan":
            profitRate = 20; // Replace with actual profit calculation
            break;
        case "Premium Plan":
            profitRate = 30; // Replace with actual profit calculation
            break;
        default:
            profitRate = 0;
    }

    // Example of updating profit every second (for demo purposes)
    let profit = 0;
    const profitDisplay = document.createElement('div');
    profitDisplay.innerText = `Current Profit: $${profit}`;
    document.body.appendChild(profitDisplay);
    
    const interval = setInterval(() => {
        profit += profitRate;
        profitDisplay.innerText = `Current Profit: $${profit}`;
        
        // Stop updating after 10 seconds for demo purposes
        if (profit >= 100) { // Adjust this condition as needed
            clearInterval(interval);
        }
    }, 1000);
}